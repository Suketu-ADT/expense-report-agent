# ExpenseFlow large dataset

Use this pack to test receipt matching, reimbursement rules, human review, saved reports, and PDF export with 500 synthetic claims. The claims cover four expense categories and use INR throughout. Receipts are TXT or digital PDF and work without Tesseract.

## Run the full test automatically

Extract this archive. In PowerShell, open the extracted folder that contains **run_test.py** and run the following. Adjust the backend path if you moved the project.

```powershell
$backend = 'C:\Users\Arpit singh\OneDrive\Desktop\Agentic AI\expense-report-agent\backend'
& "$backend\.venv\Scripts\python.exe" .\run_test.py --backend $backend
```

The script uses the project's Python dependencies and a temporary copy of the backend. It checks all 500 rows against expected decisions, processes the receipt batches and simulated reviewer actions, then writes **results/verification.json** and **results/reimbursement-report.pdf**. Progress appears after every ten batches and every sixteen reviewer actions. The live app, imported CSV, and database are unaffected. The test exercises the approval gate while claims are held. It uses simulated email mode and finishes at PDF export.

## Test in the browser

1. In ExpenseFlow, upload **claims.csv**. Keep a copy of any existing CSV you want to reuse because browser import replaces the current file for future runs.
2. Turn on **Apply reimbursement policy**, set the meal limit to **800**, and use this request: **Generate my travel expense report for July 2026.**
3. Generate the report and open **Review claim decisions**. Use **Add receipt** to attach the four files in **attach-first** to their corresponding expense IDs. This establishes the original use of four receipt IDs for the reuse tests.
4. Under **Receipt matching**, upload one numbered folder at a time, starting with **receipt-batches/batch-001**. Choose all the files in that folder and click **Match uploaded receipts**. Each folder contains up to eight files. Keep both alternatives together when testing ambiguous matches.
5. Compare the results with **expected-claims.csv**. Follow the reviewer actions in **test-plan.json** if you want to finish every exception manually. Use **Correct receipt fields** and paste the corresponding file from **review-evidence** for conflicting totals. For ambiguous matches, attach the verified receipt from **review-evidence**. Accept the evidenced amounts for mismatches. Reject the synthetic missing and reused receipt claims.
6. Download the final PDF after the held count reaches zero. **Approve and send** is optional. It can send real mail if you launched the server with **DEVELOPMENT_MODE=false**.

## Expected decisions

| Scenario | Rows | Expected behavior |
| --- | ---: | --- |
| Exact matches | 296 | Verified and fully eligible |
| Meals above the cap | 116 | Approved at INR 800 per claim |
| Original receipts for reuse tests | 4 | Attached manually before the batch |
| Reused receipt IDs | 4 | Held, then rejected |
| Receipt amount mismatches | 30 | Held, then accepted at the evidenced amount |
| Missing receipts | 12 | Held, then rejected |
| Ambiguous matches | 10 | Held until the correct receipt is assigned |
| Conflicting receipt totals | 8 | Held until the reading is corrected |
| Duplicate CSV rows | 10 | Excluded by validation |
| August rows | 10 | Excluded from the July report |

A July run should retain 480 claims. After processing all receipt batches, 64 claims should be held. After the scripted reviewer actions, zero should remain held. **test-plan.json** records exact expected totals in paise. **expected-claims.csv** records expected status and approved amounts in INR per row. **example-results/** contains the verified output from one replay.

