
"""Replay this dataset in a temporary copy of the ExpenseFlow backend."""

import argparse
from collections import Counter
import csv
from decimal import Decimal
from io import BytesIO
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from time import perf_counter
from uuid import uuid4

PACK = Path(__file__).resolve().parent


def check(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def ok(response):
    check(response.is_success, f"{response.request.method} {response.url.path}: {response.status_code} {response.text[:500]}")
    return response


def in_paise(value):
    return int(Decimal(value) * 100)


def verify_claims(sheet, expected, prefix):
    items = {item["id"]: item for item in sheet["items"]}
    unknown = items.keys() - expected.keys()
    check(not unknown, f"Unexpected claim IDs: {sorted(unknown)}")
    for claim_id, row in expected.items():
        item = items.get(claim_id, {"status": "excluded", "approved": 0})
        target = (row[f"{prefix}_status"], in_paise(row[f"{prefix}_approved_inr"]))
        actual = (item["status"], item["approved"])
        check(actual == target, f"{prefix} {claim_id}: expected {target}, got {actual}")
    return items


def replay(output):
    from fastapi.testclient import TestClient
    from pypdf import PdfReader
    from app.main import app

    plan = json.loads((PACK / "test-plan.json").read_text(encoding="utf-8"))
    target = plan["expected"]
    with (PACK / "expected-claims.csv").open(newline="", encoding="utf-8") as stream:
        expected = {row["expense_id"]: row for row in csv.DictReader(stream)}

    started = perf_counter()
    with TestClient(app) as client:
        ok(client.post("/api/expenses/import", files={"file": ("claims.csv", (PACK / "claims.csv").read_bytes())}))
        run = ok(client.post("/api/run", json={
            "request_text": plan["request"],
            "user_id": "large-dataset-test",
            "policy": {"meal_cap": plan["meal_cap"]},
        })).json()
        url = f"/api/run/{run['run_id']}"
        run_data = ok(client.get(url)).json()
        check(run_data.get("status") == "completed", f"Run failed: {run_data.get('errors')}")
        sheet = run_data["reimbursement"]
        check(len(run_data["raw_expenses"]) == target["source_rows"], "Source row count differs")
        check(len(sheet["items"]) == target["included_rows"], "Included row count differs")
        duplicates = sum(f["problem"] == "Duplicate" and f["status"] == "EXCLUDED"
                         for f in run_data["missing_data_flags"])
        check(duplicates == target["duplicate_rows"], "Duplicate exclusion count differs")
        indexes = {item["id"]: index for index, item in enumerate(sheet["items"])}

        def attach(entry):
            path = PACK / entry["path"]
            index = indexes[entry["expense_id"]]
            return ok(client.post(
                f"{url}/claims/{index}/receipt", params={"revision": sheet["revision"]},
                files={"file": (path.name, path.read_bytes())},
            )).json()

        for entry in plan["attach_first"]:
            sheet = attach(entry)

        checks = {
            "receipt_reuse": "already supports another claim",
            "ambiguous_match": "Multiple receipts or claims",
            "amount_mismatch": "differs from the claim",
            "conflicting_totals": "unreadable or ambiguous",
            "missing_receipt": "Provide a receipt",
        }
        confirmed_findings = set()
        batches = plan["batches"]
        batch_started = perf_counter()
        for number, batch in enumerate(batches, 1):
            files = [("files", (Path(name).name, (PACK / name).read_bytes())) for name in batch]
            sheet = ok(client.post(f"{url}/receipt-review", params={"revision": sheet["revision"]}, files=files)).json()
            for decision in sheet["receipt_review"]["claims"]:
                claim_id = decision["claim_id"]
                marker = checks.get(expected[claim_id]["scenario"])
                if marker and marker in decision["verification"]:
                    confirmed_findings.add(claim_id)
            if number % 10 == 0 or number == len(batches):
                print(f"{number}/{len(batches)} batches processed, {sheet['held']} held", flush=True)

        batch_elapsed = perf_counter() - batch_started
        after = verify_claims(sheet, expected, "after_batch")
        required = {claim_id for claim_id, row in expected.items() if row["scenario"] in checks}
        check(required == confirmed_findings, f"Missing agent findings: {sorted(required - confirmed_findings)}")
        observed = {
            "source_rows": len(run_data["raw_expenses"]),
            "included_rows": len(after),
            "duplicate_rows": duplicates,
            "outside_period_rows": sum(row["scenario"] == "outside_period" and cid not in after
                                       for cid, row in expected.items()),
            "claimed_paise": sheet["claimed"],
            "after_batch_approved_paise": sheet["approved"],
            "after_batch_holds": sheet["held"],
        }
        check(sheet["held"] > 0, "Expected held claims before review")
        check(client.post(f"{url}/approve").status_code == 409, "Approval gate did not block held claims")

        review_started = perf_counter()
        for number, entry in enumerate(plan["review_actions"], 1):
            if entry["action"] == "attach":
                sheet = attach(entry)
            else:
                index = indexes[entry["expense_id"]]
                payload = {"revision": sheet["revision"], "action": entry["action"], "note": entry["note"]}
                if entry["action"] == "correct":
                    payload["text"] = (PACK / entry["path"]).read_text(encoding="utf-8")
                sheet = ok(client.post(f"{url}/claims/{index}", json=payload)).json()
            if number % 16 == 0:
                print(f"{number}/{len(plan['review_actions'])} reviewer actions processed", flush=True)

        review_elapsed = perf_counter() - review_started
        final = verify_claims(sheet, expected, "final")
        observed.update(final_approved_paise=sheet["approved"], final_difference_paise=sheet["difference"],
                        final_holds=sheet["held"])
        check(target == observed, f"Expected {target}, got {observed}")
        saved = ok(client.get(f"/api/reports/{run_data['report_id']}")).json()
        check(saved.get("reimbursement") == sheet, "Saved report does not match the final sheet")
        pdf = ok(client.get(f"{url}/reimbursement.pdf")).content

    reader = PdfReader(BytesIO(pdf))
    first_page = reader.pages[0].extract_text()
    check(f"Approved (INR): {sheet['approved'] / 100:.2f}" in first_page, "PDF total differs from the final sheet")
    pdf_claims = {line.split(" | ", 1)[0] for page in reader.pages for line in page.extract_text().splitlines()
                  if line.startswith("EF-") and " | " in line}
    check(pdf_claims == final.keys(), f"PDF failed to show {len(final.keys() - pdf_claims)} claim IDs")
    result = {
        "result": "passed",
        "observed": observed,
        "assessed_claims": len(expected),
        "batch_files": sum(map(len, batches)),
        "batches": len(batches),
        "review_actions": len(plan["review_actions"]),
        "agent_findings_confirmed": len(confirmed_findings),
        "final_status_counts": dict(Counter(item["status"] for item in final.values())),
        "pdf_pages": len(reader.pages),
        "seconds_this_run": {
            "receipt_batches": round(batch_elapsed, 2),
            "review_actions": round(review_elapsed, 2),
            "total": round(perf_counter() - started, 2),
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    (output / "reimbursement-report.pdf").write_bytes(pdf)
    print(json.dumps(result, indent=2), flush=True)
    print(f"\nSaved results to {output}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", type=Path, help="Path to expense-report-agent/backend")
    parser.add_argument("--output", type=Path, default=PACK / "results")
    parser.add_argument("--isolated-worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.isolated_worker:
        sys.path.insert(0, str(Path.cwd()))
        replay(output)
        return
    if not args.backend or not (args.backend / "app" / "main.py").is_file():
        parser.error("--backend must point to the backend folder containing app/main.py")

    env = {**os.environ, "DEVELOPMENT_MODE": "true", "PYTHONUNBUFFERED": "1"}
    with TemporaryDirectory(prefix="expenseflow-dataset-") as sandbox:
        shutil.copytree(args.backend / "app", Path(sandbox) / "app", ignore=shutil.ignore_patterns("__pycache__"))
        completed = subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), "--isolated-worker", "--output", str(output)],
            cwd=sandbox, env=env,
        )
        if completed.returncode:
            raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()

